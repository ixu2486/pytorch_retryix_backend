"""
PyTorch RetryIX Backend - 官方AMD GPU支持

這個模塊提供了對AMD GPU的原生支持，使用RetryIX持久記憶體技術
實現高性能的深度學習操作。

使用示例:
    import torch
    import pytorch_retryix_backend as rx

    # 初始化後端
    rx.init()

    # 使用RetryIX設備
    device = torch.device("privateuseone:0")
    tensor = torch.randn(1000, 1000, device=device)

    # 所有PyTorch操作自動優化
    result = torch.matmul(tensor, tensor)
"""

import torch
import os
import sys
import warnings

# Preload critical DLLs BEFORE any C++ extension import (Windows only)
if os.name == 'nt':
    try:
        import ctypes
        # Add torch lib directory to DLL search path
        torch_dir = os.path.dirname(torch.__file__)
        torch_lib_dir = os.path.join(torch_dir, 'lib')
        if os.path.isdir(torch_lib_dir):
            os.add_dll_directory(torch_lib_dir)
            
            # Preload torch DLLs
            for dll_name in ['c10.dll', 'torch.dll', 'torch_cpu.dll', 'torch_python.dll']:
                dll_path = os.path.join(torch_lib_dir, dll_name)
                if os.path.exists(dll_path):
                    ctypes.CDLL(dll_path)
            
            # Preload Vulkan and RetryIX
            try:
                ctypes.WinDLL('vulkan-1.dll')
            except:
                pass
            
            # no legacy v2 DLL is loaded; the Rust FFI layer provides
            # all functionality and is shipped alongside the package.
            pkg_dir = os.path.dirname(__file__)
            retryix_ffi_dll = os.path.join(pkg_dir, "retryix_ffi.dll")
            if os.path.exists(retryix_ffi_dll):
                try:
                    ctypes.CDLL(retryix_ffi_dll)
                except:
                    pass
    except Exception:
        pass

# Enforce: only Python 3.11 is supported for this build.
# Fail early with a clear message to avoid ABI/extension runtime errors.
if sys.version_info[:2] != (3, 11):
    raise RuntimeError(
        "pytorch_retryix_backend: this build **requires Python 3.11.x** "
        f"(detected {sys.version_info.major}.{sys.version_info.minor}). "
        "Please use a Python 3.11 virtual environment."
    )

__version__ = "3.1.4"
__author__ = "RetryIX Team"
__description__ = "RetryIX PyTorch PrivateUse1 backend — Vulkan compute for universal GPUs"

# 全局狀態
_initialized = False
_available_devices = []
_cpp_extension_available = False


def set_cpu_fallback_prohibited(value: bool):
    """Prohibit any CPU fallback when True.

    Raises a RuntimeError if the underlying C extension does not support this
    control.  Use this before launching persistent GEMM loops.
    """
    from . import _C
    if not hasattr(_C, 'retryix_set_cpu_fallback_prohibited'):
        raise RuntimeError("CPU fallback control not available in this build")
    _C.retryix_set_cpu_fallback_prohibited(bool(value))


def is_cpu_fallback_prohibited() -> bool:
    """Return current CPU fallback prohibition state."""
    from . import _C
    if not hasattr(_C, 'retryix_is_cpu_fallback_prohibited'):
        return False
    return bool(_C.retryix_is_cpu_fallback_prohibited())

# 操作實現
_add_impl = None
_matmul_impl = None
_zeros_impl = None
_ones_impl = None
_randn_impl = None

class RetryIXDevice:
    """RetryIX設備類"""
    def __init__(self, device_index=0):
        self.device_index = device_index
        self.type = 'privateuseone'

    def __str__(self):
        return f'privateuseone:{self.device_index}'

    def __repr__(self):
        return f'RetryIXDevice({self.device_index})'

class RetryIXAllocator:
    """RetryIX 記憶體分配器（**GPU-only — 不使用 CPU/DRAM**）。

    - 嚴格禁止 CPU fallback：如果後端未就緒或 Vulkan 不可用，會拋出錯誤。
    - 使用時請先調用 `register_vulkan_allocator()` 或 `init()` 以註冊並初始化 GPU 後端。
    """
    def allocate(self, size):
        # Strict GPU-only allocation — NO CPU/DRAM fallback.
        # Validate inputs.
        if size is None:
            raise ValueError("size must be provided for GPU allocation")

        # Ensure the C++ extension and Vulkan allocator are available — fail loudly.
        try:
            from . import _C
        except Exception:
            raise RuntimeError("GPU allocator unavailable: C++ extension not loaded. Call register_vulkan_allocator() / init() first.")

        if hasattr(_C, "is_vulkan_available") and not _C.is_vulkan_available():
            raise RuntimeError("Vulkan backend not available (no CPU fallback). Call register_vulkan_allocator() / init() first.")

        # Normalize shape and allocate on the PrivateUse1 device (will raise if backend not registered).
        shape = (size,) if isinstance(size, int) else tuple(size)
        t = torch.empty(shape, dtype=torch.uint8, device=torch.device("privateuseone:0"))
        return t.data_ptr()

    def deallocate(self, ptr):
        # Deallocation for GPU allocations is managed by the backend / allocator.
        # Expose a hard error to prevent accidental CPU frees.
        raise RuntimeError("deallocate() unsupported for GPU-only allocator; let the backend manage GPU memory or free via the C++ API.")

def _probe_import_extension(timeout: int = 15):
    """在子進程中嘗試匯入編譯後的 `_C` 擴展，檢測是否會觸發原生層級崩潰。

    - 返回 (success: bool, output: str)。
    - 在 Windows 上用於避免在主進程做會導致 DLL 初始化崩潰的匯入操作。
    """
    import subprocess, sys
    try:
        pkg_root = os.path.dirname(os.path.dirname(__file__))
        pkg_dir = os.path.dirname(__file__)          # pytorch_retryix_backend/ — retryix_ffi.dll 在此
        torch_lib = os.path.join(os.path.dirname(torch.__file__), 'lib')
        
        # 构建命令，包括 DLL 路径设置
        cmd = [
            sys.executable,
            "-c",
            (
                "import sys, os, importlib;\n"
                "if hasattr(os, 'add_dll_directory'):\n"
                "    os.add_dll_directory(r'{pkg_dir}');\n"
                "    os.add_dll_directory(r'{torch_lib}');\n"
                "sys.path.insert(0, r'{root}');\n"
                "importlib.import_module('pytorch_retryix_backend._C'); print('OK')"
            ).format(root=pkg_root, torch_lib=torch_lib, pkg_dir=pkg_dir)
        ]
        completed = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        out = (completed.stdout or "") + (completed.stderr or "")
        return (completed.returncode == 0, out)
    except Exception as e:
        return (False, str(e))


def set_cpu_fallback_prohibited(value: bool):
    """When True any attempt to use a CPU fallback will raise an exception.

    This is useful when running persistent GEMM kernels where a single
    CPU copy may corrupt GPU memory.  Defaults to False.
    """
    from . import _C
    if not hasattr(_C, 'retryix_set_cpu_fallback_prohibited'):
        raise RuntimeError("This build does not support CPU fallback control")
    _C.retryix_set_cpu_fallback_prohibited(bool(value))


def is_cpu_fallback_prohibited() -> bool:
    """Query current prohibition state."""
    from . import _C
    if not hasattr(_C, 'retryix_is_cpu_fallback_prohibited'):
        return False
    return bool(_C.retryix_is_cpu_fallback_prohibited())


def _register_backend():
    """註冊PyTorch後端 - 使用C++擴展"""
    global _add_impl, _matmul_impl, _zeros_impl, _ones_impl, _randn_impl, _cpp_extension_available

    try:
        # 嘗試載入C++擴展
        # On Windows the compiled extension may depend on DLLs shipped with the installed
        # torch package (e.g. torch_cpu.dll, torch_python.dll). Ensure that directory is
        # added to the DLL search path before importing the extension so LoadLibrary
        # can resolve dependencies.
        try:
            # On Windows do a subprocess probe first to detect .pyd/DLL init crashes
            if os.name == 'nt' and os.environ.get('RETRYIX_SAFE_IMPORT_PROBE', '1') != '0':
                ok, probe_out = _probe_import_extension()
                if not ok:
                    # Fail fast without importing the .pyd in-process (avoids crashing the Python process)
                    _cpp_extension_available = False
                    print('[rx.init] Subprocess probe import of _C failed — skipping in-process import to avoid crash')
                    print('[rx.init] probe output:\n' + probe_out)
                    raise ImportError('Subprocess probe import of _C failed; see logs for details')

            if os.name == 'nt':
                try:
                    import ctypes
                    _pkg_dir = os.path.dirname(__file__)
                    torch_dir = os.path.dirname(torch.__file__)
                    torch_lib_dir = os.path.join(torch_dir, 'lib')
                    # 套件目錄必須先加入，retryix_ffi.dll 在此
                    if os.path.isdir(_pkg_dir):
                        os.add_dll_directory(_pkg_dir)
                        print(f"[rx.init] added pkg dir to DLL search path: {_pkg_dir}")
                    if os.path.isdir(torch_lib_dir):
                        os.add_dll_directory(torch_lib_dir)
                        print(f"[rx.init] added torch lib dir to DLL search path: {torch_lib_dir}")
                        
                        # Preload critical torch DLLs to satisfy _C.pyd dependencies
                        torch_dlls = ['c10.dll', 'torch.dll', 'torch_cpu.dll', 'torch_python.dll']
                        for dll_name in torch_dlls:
                            dll_path = os.path.join(torch_lib_dir, dll_name)
                            if os.path.exists(dll_path):
                                try:
                                    ctypes.CDLL(dll_path)
                                    print(f"[rx.init] preloaded {dll_name}")
                                except Exception as dll_err:
                                    print(f"[rx.init] warning: failed to preload {dll_name}: {dll_err}")
                        
                        # Preload RetryIX and Vulkan DLLs
                        try:
                            ctypes.WinDLL('vulkan-1.dll')  # System vulkan loader
                            print("[rx.init] preloaded vulkan-1.dll")
                        except Exception:
                            pass
                        
                        # retryix_ffi.dll — Rust FFI layer，必須優先於 retryix_v2.dll 載入
                        try:
                            retryix_ffi_dll = os.path.join(_pkg_dir, 'retryix_ffi.dll')
                            if os.path.exists(retryix_ffi_dll):
                                ctypes.CDLL(retryix_ffi_dll)
                                print("[rx.init] preloaded retryix_ffi.dll")
                        except Exception as rf_err:
                            print(f"[rx.init] warning: failed to preload retryix_ffi.dll: {rf_err}")
                            
                except Exception as e:
                    # non-fatal - continue to import and let the import error surface
                    print(f"[rx.init] DLL preload failed: {e}")
                    pass

            # Use absolute import with explicit package name to ensure correct module resolution
            import pytorch_retryix_backend._C as _C
            _cpp_extension_available = True
            # Import autograd extension — this module's TORCH_LIBRARY_IMPL static
            # initializer registers all AutogradPrivateUse1 kernels (mul, add, relu…).
            # Must happen AFTER _C is loaded so PrivateUse1 is already registered.
            try:
                import pytorch_retryix_backend._retryix_autograd_cpp  # noqa: F401
                print('[rx.init] AutogradPrivateUse1 kernels registered (_retryix_autograd_cpp)')
            except ImportError as ag_err:
                print(f'[rx.init] WARNING: autograd extension not available: {ag_err}')
                print('[rx.init] backward() will use PyTorch default autograd (no custom backward)')
            # Ensure the PrivateUse1 hooks are registered (idempotent helper in C++ extension)
            try:
                # Some build variants may NOT export `is_privateuse1_hooks_registered` helper
                # from the C++ extension. In that case we still want to attempt a best-effort
                # registration using any available helpers (register_retryix_hooks_local,
                # force_register_privateuse1_hooks) and finally fall back to
                # register_vulkan_allocator() which *does* register the hooks.
                registered = False
                if hasattr(_C, 'is_privateuse1_hooks_registered'):
                    try:
                        registered = bool(_C.is_privateuse1_hooks_registered())
                    except Exception:
                        registered = False

                if not registered:
                    # Prefer explicit hooks registration helper if available
                    if hasattr(_C, 'register_retryix_hooks_local'):
                        print('[rx.init] registering PrivateUse1 hooks via _C.register_retryix_hooks_local()')
                        _C.register_retryix_hooks_local()
                    # Prefer the explicit force helper if present in the loaded _C
                    elif hasattr(_C, 'force_register_privateuse1_hooks'):
                        print('[rx.init] registering PrivateUse1 hooks via _C.force_register_privateuse1_hooks()')
                        try:
                            _C.force_register_privateuse1_hooks()
                        except Exception as e:
                            print(f"[rx.init] force_register_privateuse1_hooks() failed: {e}")
                    # Final fallback: registering the Vulkan allocator also installs PrivateUse1 hooks
                    elif hasattr(_C, 'register_vulkan_allocator'):
                        print('[rx.init] is_privateuse1_hooks_registered not exported by _C — calling register_vulkan_allocator() fallback')
                        try:
                            _C.register_vulkan_allocator()
                        except Exception as e:
                            print(f"[rx.init] fallback register_vulkan_allocator() failed: {e}")
            except Exception:
                pass
            print("✅ 載入C++擴展成功")
        except ImportError as e:
            _cpp_extension_available = False
            raise RuntimeError(f"❌ C++擴展不可用，無法載入RetryIX後端: {e}")

        # 使用C++實現 - 直接使用PrivateUse1 kernel函數
        empty_privateuse1 = _C.empty_privateuse1
        zeros_privateuse1 = _C.zeros_privateuse1
        ones_privateuse1 = _C.ones_privateuse1

        # 將它們設為模塊級別的函數
        globals()['empty_privateuse1'] = empty_privateuse1
        globals()['zeros_privateuse1'] = zeros_privateuse1
        globals()['ones_privateuse1'] = ones_privateuse1

        # ── Issue-3 fix: 綁定 _*_impl 使 rxb.zeros()/randn()/matmul() 可用 ──────
        _dev = torch.device('privateuseone:0')
        def _mk(sizes): return list(sizes) if hasattr(sizes, '__iter__') and not isinstance(sizes, torch.Tensor) else [sizes]
        global _add_impl, _matmul_impl, _zeros_impl, _ones_impl, _randn_impl
        _zeros_impl  = lambda sizes, dtype=None, layout=None, device=None, pin_memory=None: \
            torch.zeros(_mk(sizes), dtype=dtype, device=device if device is not None else _dev)
        _ones_impl   = lambda sizes, dtype=None, layout=None, device=None, pin_memory=None: \
            torch.ones(_mk(sizes),  dtype=dtype, device=device if device is not None else _dev)
        _randn_impl  = lambda sizes, dtype=None, layout=None, device=None: \
            torch.randn(_mk(sizes), dtype=dtype, device=device if device is not None else _dev)
        _add_impl    = lambda a, b: torch.add(a, b)
        _matmul_impl = lambda a, b: torch.matmul(a, b)
        print("✅ _zeros_impl / _ones_impl / _randn_impl / _add_impl / _matmul_impl bound to torch dispatch")
        # ─────────────────────────────────────────────────────────────────────

        # 新增 persistent pool Python wrapper
        def allocate_persistent(key: str, size: int) -> bool:
            return _C.allocate_persistent_buffer(key, int(size))

        def allocate_persistent_from_host(key: str, payload: bytes) -> bool:
            return _C.allocate_persistent_buffer_from_host(key, payload)

        def free_persistent(key: str) -> bool:
            return _C.free_persistent_buffer(key)

        def get_persistent_info(key: str):
            found, memType, propFlags, ptr, size = _C.get_persistent_info(key)
            return {
                'found': bool(found),
                'memoryTypeIndex': int(memType),
                'propertyFlags': int(propFlags),
                'ptr': int(ptr),
                'size': int(size),
            }

        def list_persistent_buffers():
            return list(_C.list_persistent_buffers())

        def preload_shaders(shader_dir: str = None):
            # preload gemm* and integrate* SPIR-V blobs into persistent VRAM buffers
            import glob, os
            d = shader_dir or os.path.join(os.path.dirname(__file__), '..', '..', 'shaders')
            # tolerate absolute workspace path
            if not os.path.isdir(d):
                d = os.path.join(os.getcwd(), 'shaders')
            patterns = ['gemm*.spv', 'integrate*.spv']
            loaded = []
            for pat in patterns:
                for path in glob.glob(os.path.join(d, pat)):
                    key = os.path.basename(path)
                    try:
                        with open(path, 'rb') as f:
                            data = f.read()
                        if _C.allocate_persistent_buffer_from_host(key, data):
                            loaded.append(key)
                    except Exception as e:
                        print(f"preload_shaders: failed to load {path}: {e}")
            return loaded

        globals()['allocate_persistent'] = allocate_persistent
        globals()['allocate_persistent_from_host'] = allocate_persistent_from_host
        globals()['free_persistent'] = free_persistent
        globals()['get_persistent_info'] = get_persistent_info
        globals()['list_persistent_buffers'] = list_persistent_buffers
        globals()['preload_shaders'] = preload_shaders

        print("✅ PrivateUse1 kernel函數已載入")

        # Re-export optional C++ helper bindings from the compiled `_C` extension so
        # callers can always use the Python-level helpers regardless of which TU
        # exported them. Missing helpers get an informative stub.
        def _make_missing(name):
            def _missing(*args, **kwargs):
                raise RuntimeError(f"C++ helper '{name}' is not available in this build of the _C extension")
            return _missing

        for _helper in (
            'register_retryix_hooks',
            'register_retryix_hooks_local',
            'is_privateuse1_hooks_registered',
            'register_vulkan_allocator',
            'force_register_privateuse1_hooks',
            'get_backend',
            'set_backend',
        ):
            if hasattr(_C, _helper):
                globals()[_helper] = getattr(_C, _helper)
            else:
                # sensible default for the boolean query
                if _helper == 'is_privateuse1_hooks_registered':
                    globals()[_helper] = lambda: False
                else:
                    globals()[_helper] = _make_missing(_helper)

        # Expose a small convenience wrapper used by some tests/scripts
        def ensure_privateuse1_hooks_registered():
            """Ensure PrivateUse1 hooks are registered (idempotent).

            Tries exported helpers in a best-effort order and raises a clear
            error if none are available.
            """
            if globals().get('is_privateuse1_hooks_registered', lambda: False)():
                return True
            if callable(globals().get('register_retryix_hooks_local')):
                return globals()['register_retryix_hooks_local']()
            if callable(globals().get('register_retryix_hooks')):
                return globals()['register_retryix_hooks']()
            raise RuntimeError('No available helper to register PrivateUse1 hooks in the C++ extension')

        globals()['ensure_privateuse1_hooks_registered'] = ensure_privateuse1_hooks_registered

        # 重命名privateuseone後端為rocm（AMD ROCm平台，對應NVIDIA CUDA）
        from torch.utils.backend_registration import rename_privateuse1_backend, generate_methods_for_privateuse1_backend
        try:
            rename_privateuse1_backend('retryix')  # 使用retryix而不是rocm避免内部检查
            print("✅ PrivateUse1 backend重命名为: retryix")
        except Exception as _ren_err:
            if "already" in str(_ren_err).lower():
                print(f"✅ PrivateUse1 backend重命名: 已套用（冪等）")
            else:
                raise
        try:
            generate_methods_for_privateuse1_backend()
            print("✅ PyTorch RetryIX GPU後端已註冊為retryix backend")
        except Exception as _gen_err:
            if "already" in str(_gen_err).lower():
                print(f"✅ generate_methods: 已套用（冪等，{_gen_err}）")
            else:
                raise

        # Register Python-level DeviceGuard and Hooks for PrivateUse1.
        # This is the correct PyTorch API for custom backends to expose:
        #   - DeviceGuard: handles event record/wait/query (no-op for Vulkan sync)
        #   - PrivateUse1Hooks: exposes is_available, is_built, has_primary_context
        # Without these, torch.autograd backward() throws "Backend doesn't support events."
        try:
            import torch._C._acc as _acc
            import torch._C._autograd as _cauto

            class _RetryIXDeviceGuard(_acc.DeviceGuard):
                def type_(self):
                    return _cauto.DeviceType.PrivateUse1

            class _RetryIXHook(_acc.PrivateUse1Hooks):
                def is_available(self): return True
                def is_built(self): return True
                def has_primary_context(self, dev_id): return True

            ok_guard = _acc.register_python_privateuseone_device_guard(_RetryIXDeviceGuard())
            ok_hook  = _acc.register_python_privateuseone_hook(_RetryIXHook())
            print(f"✅ RetryIX Python DeviceGuard注册: {ok_guard}, Hook注册: {ok_hook}")
        except Exception as _dg_err:
            print(f"⚠ RetryIX DeviceGuard/Hook注册失败: {_dg_err}")

        # Ensure `aten::empty.memory_format` is callable for the `retryix` backend by
        # forwarding to the already-registered `aten::empty` kernel (which is
        # registered for PrivateUse1). This avoids Python-level kernels masking C++
        # implementations while still handling schema overload differences.
        try:
            @torch.library.impl("aten::empty.memory_format", "retryix")
            def _py_empty_memory_format_retryix(size, *, dtype=None, layout=None, device=None, pin_memory=None, memory_format=None):
                # Call the C++ direct export to avoid dispatcher recursion.
                # Ensure dtype is a real torch.dtype (C API doesn't accept None).
                real_dtype = dtype if dtype is not None else torch.get_default_dtype()
                return _C.empty_privateuse1(size, real_dtype, device)
        except Exception:
            # non-fatal if registration fails for any reason
            pass

        # Register missing bitwise / comparison ops with CPU fallback.
        # These are NOT in the compiled _C.pyd (Batch 1-12) but are required by
        # PyTorch internals – most notably the tensor __repr__/print path which
        # calls aten::bitwise_and.Tensor_out to format integer masks internally.
        # Using "PrivateUse1" as the dispatch key (backend rename to "retryix" is
        # only for device-type strings; the internal dispatch key stays PrivateUse1).
        _bitwise_ops_registered = False
        for _dispatch_key in ("PrivateUse1", "retryix"):
            try:
                @torch.library.impl("aten::bitwise_and.Tensor_out", _dispatch_key)
                def _bitwise_and_tensor_out(self, other, out):
                    result = torch.bitwise_and(self.cpu(), other.cpu())
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_and.Scalar_out", _dispatch_key)
                def _bitwise_and_scalar_out(self, other, out):
                    result = torch.bitwise_and(self.cpu(), other)
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_or.Tensor_out", _dispatch_key)
                def _bitwise_or_tensor_out(self, other, out):
                    result = torch.bitwise_or(self.cpu(), other.cpu())
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_or.Scalar_out", _dispatch_key)
                def _bitwise_or_scalar_out(self, other, out):
                    result = torch.bitwise_or(self.cpu(), other)
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_xor.Tensor_out", _dispatch_key)
                def _bitwise_xor_tensor_out(self, other, out):
                    result = torch.bitwise_xor(self.cpu(), other.cpu())
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_xor.Scalar_out", _dispatch_key)
                def _bitwise_xor_scalar_out(self, other, out):
                    result = torch.bitwise_xor(self.cpu(), other)
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_not.out", _dispatch_key)
                def _bitwise_not_out(self, out):
                    result = torch.bitwise_not(self.cpu())
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_left_shift.Tensor_out", _dispatch_key)
                def _bitwise_lshift_tensor_out(self, other, out):
                    result = torch.bitwise_left_shift(self.cpu(), other.cpu())
                    out.copy_(result)
                    return out

                @torch.library.impl("aten::bitwise_right_shift.Tensor_out", _dispatch_key)
                def _bitwise_rshift_tensor_out(self, other, out):
                    result = torch.bitwise_right_shift(self.cpu(), other.cpu())
                    out.copy_(result)
                    return out

                _bitwise_ops_registered = True
                print(f"✅ Bitwise CPU fallback ops registered (key={_dispatch_key})")
                break
            except Exception as _e:
                # Try next key
                continue

        if not _bitwise_ops_registered:
            print("⚠ Bitwise CPU fallback ops could not be registered – tensor printing on retryix may fail")

        # Register CPU fallbacks for GPU elementwise ops that use alloc_retryix_like() internally.
        # The compiled _C.pyd has a bug in alloc_retryix_like(): at::empty() for retryix device
        # NOTE: Python-level elementwise CPU fallback registration REMOVED.
        # The original workaround intercepted abs/neg/pow/sqrt/exp/log/sin/cos/tanh/
        # sum/mean/ones_like/zeros_like/fill_/mul.Scalar/add.Scalar/sub.Scalar/div.Scalar
        # to route them through CPU when alloc_retryix_like() was broken (VkBuffer=0x1).
        #
        # VMA has been unified (g_ptr_to_vma_handle, retryix::vma::alloc_staging) so
        # alloc_retryix_like() now allocates valid VRAM buffers.
        # Registering Python fallbacks here OVERRIDES the C++ GPU dispatch, silently
        # routing all computation through CPU and defeating the persistent kernel.
        #
        # Policy: NO Python CPU fallback registration. Any op failure is a C++ bug to fix.
        print("✅ GPU elementwise ops: C++ pipeline active, NO Python CPU fallback")

        # NOTE: Python-level aten impl registration REMOVED for ops already in C++ _C.pyd.
        # ATen operator implementations must be registered in C++ using
        # TORCH_LIBRARY_IMPL(aten, PrivateUse1, m) { m.impl("empty.memory_format", ...); }
        # Removing the Python fallbacks prevents masking missing/incorrect C++ registrations.
        # If kernels are missing at runtime the correct fix is to add them in C++ and recompile.


        # Expose our module as `torch.retryix` via the official _register_device_module API.
        # This makes `torch.retryix` available AND satisfies PyTorch stream/event routing.
        try:
            import importlib, sys as _sys, torch as _torch
            _sys.modules['torch.retryix'] = importlib.import_module('pytorch_retryix_backend')
            if not hasattr(_torch, 'retryix'):
                _torch._register_device_module('retryix', _sys.modules['torch.retryix'])
            print("✅ torch.retryix模块已注册 (via _register_device_module)")
        except Exception as reg_err:
            # _register_device_module 已注册时直接 setattr 作为降级
            try:
                import sys as _sys2, torch as _torch2, importlib as _imp2
                setattr(_torch2, 'retryix', _sys2.modules.get('torch.retryix',
                    _imp2.import_module('pytorch_retryix_backend')))
                print(f"✅ torch.retryix模块已注册 (fallback setattr, reason: {reg_err})")
            except Exception as _e2:
                print(f"⚠ torch.retryix模块注册失败: {_e2}")
        return True

    except Exception as e:
        print(f"❌ GPU後端註冊失敗: {e}")
        print("   RetryIX後端需要C++擴展，不支持CPU fallback")
        return False

def init():
    """
    初始化PyTorch RetryIX後端

    返回:
        bool: 初始化是否成功
    """
    global _initialized, _available_devices

    if _initialized:
        print('[rx.init] already initialized — returning True', flush=True)
        return True

    try:
        print('[rx.init] starting initialization', flush=True)
        retryix_available = True  # retryix_v2.dll 已廂棄，retryix_ffi.dll (Rust) 為唯一後端
        # retryix_ffi.dll — Rust FFI layer (retryix_rs); preload before _C
        # 路徑從套件目錄動態取得，不硬編碼絕對路徑
        _pkg_dir_init = os.path.dirname(os.path.abspath(__file__))
        try:
            import ctypes as _ct
            if hasattr(os, 'add_dll_directory'):
                os.add_dll_directory(_pkg_dir_init)
            _ffi_dll = os.path.join(_pkg_dir_init, 'retryix_ffi.dll')
            if os.path.exists(_ffi_dll):
                _ct.CDLL(_ffi_dll)
                print("✅ retryix_ffi.dll (Rust) 預載成功")
            else:
                print(f"⚠️  retryix_ffi.dll 不在套件目錄: {_pkg_dir_init}")
        except Exception as _ffi_err:
            print(f"⚠️  retryix_ffi.dll 預載失敗 (非致命): {_ffi_err}")

        # 註冊PyTorch後端 - 強制要求成功
        print('[rx.init] calling _register_backend()', flush=True)
        if not _register_backend():
            raise RuntimeError(
                "❌ CRITICAL: GPU後端註冊失敗！\n"
                "   RetryIX需要C++擴展來提供GPU支持。\n"
                "   請確保：\n"
                "   1. 已安裝Vulkan SDK (https://vulkan.lunarg.com/sdk/home)\n"
                "   2. 已編譯PyTorch RetryIX擴展\n"
                "   3. Vulkan驅動正確安裝\n"
                "   \n"
                "   CPU fallback已被禁用 - 此系統需要GPU加速。"
            )
        print('[rx.init] _register_backend() returned True', flush=True)

        _available_devices = [RetryIXDevice(0)]  # 真正的GPU設備
        _initialized = True

        # ── Issue-4 fix: 無 Vulkan GPU 時自動切換後端至 'cpu' ─────────────────
        try:
            from . import _C as _C_be
            if hasattr(_C_be, 'is_vulkan_available') and not _C_be.is_vulkan_available():
                if hasattr(_C_be, 'set_backend'):
                    _C_be.set_backend('cpu')
                    print("⚠ Vulkan 裝置不可用 — 後端已自動切換至 'cpu'")
                else:
                    print("⚠ Vulkan 裝置不可用且 set_backend 未匯出；請手動呼叫 rxb.set_backend('cpu')")
        except Exception as _be_err:
            print(f"⚠ 後端自動選擇時發生例外 (非致命): {_be_err}")
        # ─────────────────────────────────────────────────────────────────────

        # 注入 memory_* API 到 torch.retryix 命名空間
        _inject_memory_api_to_torch()

        # 如果 C++ 擴展可用，嘗試預載 shaders 到持久 buffer（寬容失敗）
        # 如果 C++ 擴展可用，不在初始化時自動預載 shaders（避免在 init 中觸發潛在的本地崩潰）
        if _cpp_extension_available:
            print('[rx.init] _cpp_extension_available is True — skipping automatic preload_shaders() (call rx.preload_shaders() manually)', flush=True)

        print("✅ PyTorch RetryIX後端初始化成功")
        print(f"   可用設備: {len(_available_devices)}")

        # ── view_as_complex / view_as_real (RoPE) ─────────────────────────
        # These ops have aliasing annotations in their schema which prevents
        # standard C++ m.impl() registration.  Register a CPU-fallback copy
        # via Python torch.library so that retryix tensors can use them.
        import torch.library as _tl

        def _safe_impl(op_name, dispatch_key, fn):
            try:
                _tl.impl(op_name, dispatch_key)(fn)
            except Exception:
                pass  # already registered or unsupported — ignore

        _safe_impl("aten::view_as_complex", "PrivateUse1",
            lambda inp: torch.view_as_complex(inp.cpu()).to(inp.device))
        _safe_impl("aten::view_as_real", "PrivateUse1",
            lambda inp: torch.view_as_real(inp.cpu()).to(inp.device))
        # polar — complex result stays on CPU (complex VMA not yet supported)
        _safe_impl("aten::polar", "PrivateUse1",
            lambda abs_, angle: torch.polar(abs_.cpu(), angle.cpu()))
        # linalg_vector_norm (gradient norm clipping)
        # Schema: (Tensor self, Scalar ord=2, int[1]? dim=None, bool keepdim=False,
        #          *, ScalarType? dtype=None) -> Tensor
        def _linalg_vnorm(self, ord=2, dim=None, keepdim=False, *, dtype=None):
            return torch.linalg.vector_norm(
                self.cpu(), ord=ord, dim=dim, keepdim=keepdim, dtype=dtype
            ).to(self.device)
        _safe_impl("aten::linalg_vector_norm", "PrivateUse1", _linalg_vnorm)

        # linalg_vector_norm.out — out-place variant dispatched internally by PyTorch
        # Schema: (Tensor self, Scalar ord=2, int[1]? dim=None, bool keepdim=False,
        #          *, ScalarType? dtype=None, Tensor(a!) out) -> Tensor(a!)
        def _linalg_vnorm_out(self, ord=2, dim=None, keepdim=False, *, dtype=None, out):
            result = torch.linalg.vector_norm(
                self.cpu(), ord=ord, dim=dim, keepdim=keepdim, dtype=dtype
            )
            out.copy_(result.to(out.device))
            return out
        _safe_impl("aten::linalg_vector_norm.out", "PrivateUse1", _linalg_vnorm_out)

        # ── Issue-6 fix: torch.max(t, dim=0) CPU fallback ────────────────────
        # Schema: (Tensor self, int dim, bool keepdim=False) -> (Tensor, Tensor)
        def _max_dim(self, dim, keepdim=False):
            v, idx = torch.max(self.cpu(), dim=int(dim), keepdim=bool(keepdim))
            return v.to(self.device), idx.to(self.device)

        def _max_dim_out(self, dim, keepdim=False, *, max, max_values):
            v, idx = torch.max(self.cpu(), dim=int(dim), keepdim=bool(keepdim))
            max.copy_(v.to(max.device))
            max_values.copy_(idx.to(max_values.device))
            return max, max_values

        _safe_impl("aten::max.dim",     "PrivateUse1", _max_dim)
        _safe_impl("aten::max.dim_max", "PrivateUse1", _max_dim_out)

        # ── Issue-7 fix: torch.arange(n, device=d) CPU-then-copy fallback ────
        # Avoids 0-byte temporary allocation crash inside C++ arange dispatch.
        def _arange_end(end, *, dtype=None, layout=None, device=None, pin_memory=None):
            return torch.arange(end, dtype=dtype).to(device)

        def _arange_start(start, end, *, dtype=None, layout=None, device=None, pin_memory=None):
            return torch.arange(start, end, dtype=dtype).to(device)

        def _arange_start_step(start, end, step=1, *, dtype=None, layout=None, device=None, pin_memory=None):
            return torch.arange(start, end, step, dtype=dtype).to(device)

        _safe_impl("aten::arange",            "PrivateUse1", _arange_end)
        _safe_impl("aten::arange.start",      "PrivateUse1", _arange_start)
        _safe_impl("aten::arange.start_step", "PrivateUse1", _arange_start_step)
        # ─────────────────────────────────────────────────────────────────────

        print('[rx.init] LLM view/grad-norm ops registered via Python torch.library', flush=True)

        return True

    except Exception as e:
        print(f"❌ RetryIX後端初始化失敗: {e}")
        return False

def is_retryix_available():
    """檢查RetryIX是否可用 (兼容舊接口)"""
    return _initialized and len(_available_devices) > 0

def init_retryix_backend():
    """初始化RetryIX後端 (兼容舊接口)"""
    return init()

def get_retryix_devices():
    """獲取RetryIX設備列表 (兼容舊接口)"""
    if not _available_devices:
        return []
    return [str(device) for device in _available_devices]

def device_count():
    """獲取可用RetryIX設備數量"""
    return len(_available_devices)

def get_device_properties(device_idx=0):
    """獲取設備屬性"""
    if device_idx >= len(_available_devices):
        raise ValueError(f"設備索引 {device_idx} 超出範圍")

    # 嘗試從C++擴展獲取實際設備名稱
    try:
        if _cpp_extension_available:
            actual_device_name = _C.get_device_name()
        else:
            actual_device_name = "Unknown Device (RetryIX)"
    except:
        actual_device_name = "Unknown Device (RetryIX)"

    # 返回設備屬性
    return {
        'name': actual_device_name,
        'total_memory': 8 * 1024 * 1024 * 1024,  # 8GB for RX 5700 XT
        'major': 1,
        'minor': 0,
        'multi_processor_count': 36,  # RX 5700 XT has 36 compute units
        'max_threads_per_multi_processor': 2048,
    }

def current_device():
    """獲取當前設備"""
    return _available_devices[0] if _available_devices else None

def set_device(device):
    """設置當前設備"""
    # 模擬實現
    pass

def synchronize(device=None):
    """同步設備操作"""
    # 模擬實現 - 在實際實現中這會同步GPU操作
    pass

# 兼容性函數

# Helper: lazy-call into compiled `_C` extension (loads backend if needed)
def _call_c_helper(name, *args, **kwargs):
    # Ensure C extension loaded if possible
    if not _cpp_extension_available:
        try:
            _register_backend()
        except Exception:
            pass
    if '_C' in globals() and hasattr(_C, name):
        return getattr(_C, name)(*args, **kwargs)
    raise RuntimeError(f"C++ helper '{name}' is not available in this build")

def register_retryix_hooks_local():
    return _call_c_helper('register_retryix_hooks_local')

def register_retryix_hooks():
    return _call_c_helper('register_retryix_hooks')

def is_privateuse1_hooks_registered():
    try:
        return bool(_call_c_helper('is_privateuse1_hooks_registered'))
    except Exception:
        return False

def register_vulkan_allocator(*args, **kwargs):
    """Attempt to register the Vulkan allocator.

    - If the C++ helper is missing or Vulkan/driver isn't available, raise a
      descriptive RuntimeError mentioning Vulkan so callers/tests get a clear
      message (instead of the generic _call_c_helper error).
    """
    try:
        return _call_c_helper('register_vulkan_allocator', *args, **kwargs)
    except RuntimeError as e:
        # Normalize the error message for callers/tests to check for Vulkan-related failure
        msg = str(e)
        if 'not available in this build' in msg or 'is not available' in msg:
            raise RuntimeError('Vulkan allocator helper not exported in this build') from e
        raise RuntimeError('Vulkan allocator initialization failed or Vulkan backend unavailable') from e

def force_register_privateuse1_hooks():
    return _call_c_helper('force_register_privateuse1_hooks')

def is_vulkan_available():
    """Return True if Vulkan backend appears available on this system.

    - Does NOT force allocator registration or perform Vulkan device initialization.
    - Safe to call at import time; returns False if the C++ helper is absent.
    """
    # Fast-path: if the C extension is already loaded, call through directly.
    try:
        if '_C' in globals() and hasattr(_C, 'is_vulkan_available'):
            return bool(_C.is_vulkan_available())
    except Exception:
        # Any error querying the helper should be treated as "not available".
        return False
    # If extension isn't loaded yet, return False (do NOT import _C here).
    return False

def _check_init():
    """檢查是否已初始化；若尚未初始化則自動執行 init()。"""
    if not _initialized:
        import warnings
        warnings.warn(
            "RetryIX backend not initialized — calling init() automatically. "
            "Call rxb.init() explicitly at startup to suppress this warning.",
            stacklevel=3,
        )
        init()
    if not _initialized:
        raise RuntimeError("RetryIX後端未初始化。請先調用 retryix.init()")

# 創建torch.device的輔助函數
def device(device_idx=0):
    """創建RetryIX設備"""
    _check_init()
    # 使用PyTorch的privateuseone設備類型
    return torch.device(f'privateuseone:{device_idx}')

# 張量創建輔助函數
def zeros(*sizes, dtype=None, device=None, requires_grad=False):
    """創建全零張量"""
    _check_init()
    # 使用註冊的實現
    return _zeros_impl(sizes, dtype, None, device, None)

def ones(*sizes, dtype=None, device=None, requires_grad=False):
    """創建全一张量"""
    _check_init()
    return _ones_impl(sizes, dtype, None, device, None)

def randn(*sizes, dtype=None, device=None, requires_grad=False):
    """創建隨機張量"""
    _check_init()
    return _randn_impl(sizes, dtype, None, device)

def add(a, b):
    """張量加法"""
    _check_init()
    return _add_impl(a, b)

def matmul(a, b):
    """矩陣乘法（稀疏感知路由）

    路由策略
    --------
    1. A 為稀疏且 nnz_ratio < SPARSE_GPU_THRESHOLD  → CPU torch.sparse.mm
       （避免 Vulkan staging overhead 嚴重拖累小矩陣）
    2. A 為稀疏且矩陣夠大（M*K > DENSE_PROMOTE_ELEMS）→ .to_dense() 進 GPU
    3. 其他（dense a）                               → 原有 GPU GEMM 路徑

    閾值可透過環境變數覆蓋：
      RETRYIX_SPARSE_THRESHOLD=0.3   （預設：非零比例 < 30% 走 CPU）
      RETRYIX_DENSE_PROMOTE=1048576  （預設：元素數 < 1M 強制 CPU sparse）
    """
    import os as _os
    _check_init()

    # ── 快速路徑：b 為稀疏一律轉 dense（SpMM 只支援 A 稀疏）
    if b.is_sparse or b.is_sparse_csr:
        b = b.to_dense()

    if not (a.is_sparse or a.is_sparse_csr):
        # 全 dense → 原有 GPU GEMM
        return _matmul_impl(a, b)

    # ── A 是稀疏張量 ──────────────────────────────────────────
    SPARSE_THRESHOLD   = float(_os.environ.get("RETRYIX_SPARSE_THRESHOLD",   "0.30"))
    DENSE_PROMOTE      = int(  _os.environ.get("RETRYIX_DENSE_PROMOTE",  "1048576"))

    # 取 nnz ratio
    if a.is_sparse_csr:
        nnz = int(a.values().numel())
        total = a.shape[0] * a.shape[1] if a.dim() == 2 else a.numel()
    else:
        a_c = a.coalesce()
        nnz = int(a_c._nnz())
        total = int(a_c.numel())
    nnz_ratio = nnz / max(total, 1)

    # 元素數（決定 GPU 是否划算）
    total_elems = total

    if nnz_ratio < SPARSE_THRESHOLD or total_elems < DENSE_PROMOTE:
        # CPU sparse.mm：直接利用 MKL/OpenBLAS 的 CSR kernel
        if a.device.type != 'cpu' or b.device.type != 'cpu':
            a_cpu = a.cpu() if a.device.type != 'cpu' else a
            b_cpu = b.cpu() if b.device.type != 'cpu' else b
        else:
            a_cpu, b_cpu = a, b
        # 統一轉 CSR（torch.sparse.mm 需要 COO 或 CSR，CSR 效能更佳）
        if not a_cpu.is_sparse_csr:
            a_cpu = a_cpu.to_sparse_csr()
        return torch.sparse.mm(a_cpu, b_cpu)
    else:
        # 大矩陣 + 適度稀疏：升密後走 GPU GEMM
        a_dense = a.to_dense()
        if a_dense.device.type == 'cpu':
            # 搬到 retryix device
            try:
                dev = torch.device("privateuseone:0")
                a_dense = a_dense.to(dev)
                if b.device.type == 'cpu':
                    b = b.to(dev)
            except Exception:
                return torch.mm(a_dense, b.to_dense() if (b.is_sparse or b.is_sparse_csr) else b)
        return _matmul_impl(a_dense, b)

def sparse_mm(sparse_a, dense_b, *, force_cpu: bool = False):
    """稀疏×矩陣乘法便利介面

    等價於 :func:`matmul` 但明確聲明 A 一定是稀疏張量，
    並允許呼叫端強制走 CPU 路徑（`force_cpu=True`）。
    """
    _check_init()
    if force_cpu:
        a_cpu = sparse_a.cpu()
        b_cpu = dense_b.cpu()
        if not a_cpu.is_sparse_csr:
            a_cpu = a_cpu.to_sparse_csr()
        return torch.sparse.mm(a_cpu, b_cpu)
    return matmul(sparse_a, dense_b)

class PersistentMatmul:
    """持久核心矩陣乘法 — Weight B 上傳一次永駐 VRAM/SVM。

    在稀疏算子退回 CPU 的場景中，後續所有 dense matmul 仍享有零 staging
    overhead（無 vkAllocateMemory、無 descriptor set 重建）。

    用法：
        pm = rb.PersistentMatmul(weight_tensor, max_m=512)
        out = pm(input_tensor)   # shape: [..., N]
        del pm                   # 釋放 VRAM/SVM

    參數：
        weight  : 2D Tensor [K, N] — 固定權重
        max_m   : 最大批次尺寸上限（預分配 IO 暫存緩衝區，預設 512）
    """

    _ffi = None  # ctypes CDLL — lazy-loaded

    @classmethod
    def _load_ffi(cls):
        """Lazy-load retryix_ffi.dll 並設定函式簽名（只做一次）。"""
        if cls._ffi is not None:
            return cls._ffi
        import ctypes
        import pathlib
        dll_path = pathlib.Path(__file__).parent / "retryix_ffi.dll"
        if not dll_path.exists():
            raise RuntimeError(f"PersistentMatmul: retryix_ffi.dll not found at {dll_path}")
        lib = ctypes.CDLL(str(dll_path))
        lib.retryix_gemm_session_create.restype  = ctypes.c_void_p
        lib.retryix_gemm_session_create.argtypes = [
            ctypes.POINTER(ctypes.c_float),  # weight
            ctypes.c_uint,                   # k
            ctypes.c_uint,                   # n
            ctypes.c_uint,                   # max_m
        ]
        lib.retryix_gemm_session_dispatch.restype  = ctypes.c_int
        lib.retryix_gemm_session_dispatch.argtypes = [
            ctypes.c_void_p,                 # handle
            ctypes.POINTER(ctypes.c_float),  # a
            ctypes.POINTER(ctypes.c_float),  # c  (output)
            ctypes.c_uint,                   # m
            ctypes.c_uint,                   # k
            ctypes.c_uint,                   # n
        ]
        lib.retryix_gemm_session_destroy.restype  = None
        lib.retryix_gemm_session_destroy.argtypes = [ctypes.c_void_p]
        cls._ffi = lib
        return lib

    def __init__(self, weight, max_m: int = 512):
        import ctypes
        if not isinstance(weight, torch.Tensor) or weight.dim() != 2:
            raise ValueError(
                f"PersistentMatmul: weight must be a 2D Tensor [K, N], got {getattr(weight, 'shape', type(weight))}"
            )
        w = weight.detach().cpu().contiguous().to(torch.float32)
        k, n = int(w.shape[0]), int(w.shape[1])
        lib     = self._load_ffi()
        w_ptr   = ctypes.cast(w.data_ptr(), ctypes.POINTER(ctypes.c_float))
        handle  = lib.retryix_gemm_session_create(w_ptr, k, n, int(max_m))
        if not handle:
            raise RuntimeError(
                "PersistentMatmul: retryix_gemm_session_create failed "
                "(Vulkan not available or OOM)"
            )
        self._handle = handle
        self._k      = k
        self._n      = n
        self._max_m  = int(max_m)
        self._w_ref  = w   # 保持 weight tensor 存活（避免指標失效）

    def __call__(self, a):
        """C = A × B

        a : Tensor [..., K]  →  回傳 [..., N]
        """
        import ctypes
        if not isinstance(a, torch.Tensor):
            raise TypeError(f"PersistentMatmul: expected Tensor, got {type(a)}")
        orig_shape = a.shape
        if a.dim() == 1:
            a = a.unsqueeze(0)  # [1, K]
        if a.shape[-1] != self._k:
            raise ValueError(
                f"PersistentMatmul: last dim {a.shape[-1]} != K={self._k}"
            )
        m = int(a.numel() // self._k)
        if m > self._max_m:
            raise ValueError(
                f"PersistentMatmul: m={m} exceeds max_m={self._max_m}; "
                "recreate with a larger max_m"
            )
        a_flat = a.detach().cpu().contiguous().to(torch.float32).reshape(m, self._k)
        c_flat = torch.empty(m, self._n, dtype=torch.float32)
        lib    = self._load_ffi()
        a_ptr  = ctypes.cast(a_flat.data_ptr(), ctypes.POINTER(ctypes.c_float))
        c_ptr  = ctypes.cast(c_flat.data_ptr(), ctypes.POINTER(ctypes.c_float))
        rc = lib.retryix_gemm_session_dispatch(
            self._handle, a_ptr, c_ptr,
            ctypes.c_uint(m), ctypes.c_uint(self._k), ctypes.c_uint(self._n),
        )
        if rc != 0:
            raise RuntimeError(f"PersistentMatmul: dispatch failed (rc={rc})")
        out_shape = orig_shape[:-1] + (self._n,)
        return c_flat.reshape(out_shape)

    def __del__(self):
        handle = getattr(self, '_handle', None)
        if handle:
            try:
                self._load_ffi().retryix_gemm_session_destroy(handle)
            except Exception:
                pass
            self._handle = None

    def __repr__(self):
        return (
            f"PersistentMatmul(K={self._k}, N={self._n}, max_m={self._max_m})"
        )


def empty(*sizes, dtype=None, device=None, requires_grad=False):
    """創建空張量"""
    _check_init()
    # 對於empty，使用zeros的實現（簡化）
    return _zeros_impl(*sizes, dtype=dtype, device=device, requires_grad=requires_grad)

# 匯出主要函數
__all__ = [
    'init',
    'is_available',
    'is_retryix_available',
    'init_retryix_backend',
    'get_retryix_devices',
    'device_count',
    'get_device_properties',
    'current_device',
    'set_device',
    'synchronize',
    'device',
    'zeros',
    'ones',
    'randn',
    'empty',
    'add',
    'matmul',
    'sparse_mm',
    'PersistentMatmul',
    'empty_privateuse1',
    'zeros_privateuse1',
    'ones_privateuse1',
    'get_last_alloc_info',
    # Helper exports
    'register_retryix_hooks',
    'register_retryix_hooks_local',
    'is_privateuse1_hooks_registered',
    'register_vulkan_allocator',
    'force_register_privateuse1_hooks',
    'ensure_privateuse1_hooks_registered',
    'is_vulkan_available',
    'register_retryix_as_privateuseone_alias',
    # VRAM weight pinning (zero-PCIe GEMM)
    'pin_weight',
    'unpin_weight',
    'is_weight_pinned',
    # Multimodal topology routing
    'topo_init',
    'topo_json',
    'topo_recommended_device',
    'topo_query_affinity',
    'topo_set_affinity',
    'topo_get_route',
    # Runtime Optimization Suite (v3.1.0)
    # MFE — Metric Feedback Engine
    'mfe_create',
    'mfe_destroy',
    'mfe_step',
    'mfe_set_decay',
    'mfe_read_metrics',
    'mfe_run_experiment',
    # Bus Scheduler
    'bus_init',
    'bus_cleanup',
    'bus_get_optimal_config',
    'bus_set_performance_mode',
    'bus_get_optimization_suggestions',
    'bus_benchmark_bandwidth',
    'bus_monitor_status',
    # SVM Optimizer
    'svm_suggest_optimization',
    'svm_optimize_placement',
]

# 在模塊載入時不自動導入原生 `_C` 擴展 — 使用延遲加載（_register_backend）
# Reason: importing the compiled extension at module-import time can trigger
# native/DLL initialization that crashes some CI/dev environments. Keep the
# Python module safe to import; real bindings are wired when `_register_backend()`
# is called.

# 占位符：當 C++ 擴展尚不可用時，這些函數會拋出清晰的錯誤。
def empty_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def zeros_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def ones_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def randn_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def add_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def matmul_privateuse1(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

def get_last_alloc_info(*args, **kwargs):
    raise RuntimeError("C++ extension not available")

# _cpp_extension_available remains False until `_register_backend()` successfully
# imports and initializes the compiled `_C` extension.
# Register Python-level ATen impls ONLY when the C++ extension is NOT available
if not _cpp_extension_available:
    try:
        import torch
        # Register Python wrappers for ATen ops for PrivateUse1 backend (and alias 'retryix')
        @torch.library.impl("aten::empty.memory_format", "privateuseone")
        def _py_empty_memory_format(size, *, dtype=None, layout=None, device=None, pin_memory=None, memory_format=None):
            return empty_privateuse1(size, dtype, layout, device, pin_memory, memory_format)

        @torch.library.impl("aten::zeros", "privateuseone")
        def _py_zeros(size, *, dtype=None, layout=None, device=None, pin_memory=None):
            return zeros_privateuse1(size, dtype, layout, device, pin_memory)

        @torch.library.impl("aten::ones", "privateuseone")
        def _py_ones(size, *, dtype=None, layout=None, device=None, pin_memory=None):
            return ones_privateuse1(size, dtype, layout, device, pin_memory)

        @torch.library.impl("aten::randn.generator", "privateuseone")
        def _py_randn(size, *, dtype=None, layout=None, device=None, generator=None):
            return randn_privateuse1(size, dtype, layout, device, generator)

        @torch.library.impl("aten::add.Tensor", "privateuseone")
        def _py_add(a, b, alpha):
            return add_privateuse1(a, b, alpha)

        @torch.library.impl("aten::matmul", "privateuseone")
        def _py_matmul(a, b):
            return matmul_privateuse1(a, b)

        # Also register under backend name 'retryix' if present
        try:
            @torch.library.impl("aten::empty.memory_format", "retryix")
            def _py_empty_memory_format_retryix(size, *, dtype=None, layout=None, device=None, pin_memory=None, memory_format=None):
                return _py_empty_memory_format(size, dtype=dtype, layout=layout, device=device, pin_memory=pin_memory, memory_format=memory_format)

            @torch.library.impl("aten::zeros", "retryix")
            def _py_zeros_retryix(size, *, dtype=None, layout=None, device=None, pin_memory=None):
                return _py_zeros(size, dtype=dtype, layout=layout, device=device, pin_memory=pin_memory)

            @torch.library.impl("aten::ones", "retryix")
            def _py_ones_retryix(size, *, dtype=None, layout=None, device=None, pin_memory=None):
                return _py_ones(size, dtype=dtype, layout=layout, device=device, pin_memory=pin_memory)

            @torch.library.impl("aten::randn.generator", "retryix")
            def _py_randn_retryix(size, *, dtype=None, layout=None, device=None, generator=None):
                return _py_randn(size, dtype=dtype, layout=layout, device=device, generator=generator)

            @torch.library.impl("aten::add.Tensor", "retryix")
            def _py_add_retryix(a, b, alpha):
                return _py_add(a, b, alpha)

            @torch.library.impl("aten::matmul", "retryix")
            def _py_matmul_retryix(a, b):
                return _py_matmul(a, b)
        except Exception:
            # ignore if 'retryix' backend name not yet registered
            pass
    except Exception:
        # if torch or registration API not available, skip Python-level impls
        pass

# Safe helper to register backend name 'retryix' for PrivateUse1 (DO NOT overwrite torch.device)
from torch.utils.backend_registration import rename_privateuse1_backend, generate_methods_for_privateuse1_backend

def register_retryix_as_privateuseone_alias(enable: bool = True) -> bool:
    """將 PrivateUse1 的名稱註冊/還原為 `retryix`（RetryIX Vulkan平台）。

    - enable=True: rename PrivateUse1 backend to 'retryix' 並生成方法
    - enable=False: 恢復為 'privateuseone'
    返回: 操作是否成功
    """
    try:
        if enable:
            rename_privateuse1_backend('retryix')
            generate_methods_for_privateuse1_backend()
            return True
        else:
            rename_privateuse1_backend('privateuseone')
            generate_methods_for_privateuse1_backend()
            return True
    except Exception:
        return False

# 不在模塊導入時自動註冊 backend 名稱 —— 由 _register_backend() 在初始化時處理。


# ─────────────────────────────────────────────────────────────────────────────
# VRAM Memory Management API (VulkanMemoryAllocator)
# 對應 torch.cuda.memory_allocated() / memory_reserved() / memory_summary()
# 透過 VMA 提供 OpenCL 無法實現的功能: suballocation, budget, defrag
# ─────────────────────────────────────────────────────────────────────────────

def memory_allocated(device=None) -> int:
    """回傳透過 VMA 分配給 tensor 的 VRAM bytes (DEVICE_LOCAL)。
    對應 torch.cuda.memory_allocated()。"""
    try:
        return _C.vma_memory_allocated()
    except AttributeError:
        return 0

def memory_reserved(device=None) -> int:
    """回傳 VMA 向 Vulkan 申請的 block 總量 bytes (allocated + fragmented)。
    對應 torch.cuda.memory_reserved()。"""
    try:
        return _C.vma_memory_reserved()
    except AttributeError:
        return 0

def vma_init() -> bool:
    """顯式初始化 VMA (通常不需要，memory_allocated/get_budget 會 lazy init)。"""
    try:
        return _C.vma_init()
    except AttributeError:
        return False


def pin_weight(tensor) -> bool:
    """Upload weight tensor to DEVICE_LOCAL VRAM once.

    Subsequent calls to operators using this tensor as a weight (e.g. matmul)
    will skip the PCIe upload and use a fast VRAM→VRAM copy instead
    (~448 GB/s on GDDR6 vs ~16 GB/s PCIe 4.0).

    Args:
        tensor: contiguous float32 CPU or privateuseone tensor.

    Returns:
        True on success, False if the backend is unavailable or tensor type
        is unsupported.
    """
    try:
        return bool(_C.pin_weight(tensor))
    except AttributeError:
        return False


def unpin_weight(tensor) -> None:
    """Release the DEVICE_LOCAL VRAM copy of a previously pinned weight."""
    try:
        _C.unpin_weight(tensor)
    except AttributeError:
        pass


def is_weight_pinned(tensor) -> bool:
    """Return True if *tensor* has a live DEVICE_LOCAL VRAM pin."""
    try:
        return bool(_C.is_weight_pinned(tensor))
    except AttributeError:
        return False


# ===================================================================
# Multimodal Topology API
# ===================================================================

def topo_init() -> bool:
    """Initialise multimodal topology router.

    Calls retryix_ffi.dll to discover hardware topology (NUMA layout,
    GPU device, PCIe bandwidth) and registers optimal routing for all
    five modalities: text / image / audio / video / embed.

    Call once after vma_init()."""
    try:
        return bool(_C.topo_init())
    except AttributeError:
        return False


def topo_json() -> str:
    """Return raw multimodal topology JSON from retryix_ffi."""
    try:
        return str(_C.topo_json())
    except AttributeError:
        return "{}"


def topo_recommended_device(modality: str) -> str:
    """Return recommended PyTorch device string for a modality.

    Args:
        modality: one of 'text', 'image', 'audio', 'video', 'embed'.

    Returns:
        'privateuseone:0'  (GPU)  or  'cpu'
    """
    try:
        return str(_C.topo_recommended_device(modality))
    except AttributeError:
        return "privateuseone:0"


def topo_query_affinity(workload_id: int) -> dict:
    """Query workload affinity config from retryix_ffi."""
    import json
    try:
        raw = _C.topo_query_affinity(workload_id)
        return json.loads(raw) if raw else {}
    except (AttributeError, Exception):
        return {}


def topo_set_affinity(workload_id: int, config: dict) -> bool:
    """Set workload routing affinity in retryix_ffi.

    config keys: numa_node, gpu_device, network_port,
                 rdma_enabled, gpu_audio_offload.
    """
    import json
    try:
        return bool(_C.topo_set_affinity(workload_id, json.dumps(config)))
    except AttributeError:
        return False


def topo_get_route(modality: str) -> dict:
    """Return full routing info dict for a modality.

    Returns dict with keys: workload_id, compute_device, numa_node,
    rdma_enabled, gpu_audio_offload, device, raw_json.
    """
    try:
        return dict(_C.topo_get_route(modality))
    except AttributeError:
        return {"device": "privateuseone:0", "compute_device": 0}


# ─────────────────────────────────────────────────────────────────────────────
# Runtime Optimization Suite  (v3.1.0)
# Three subsystems: MFE · Bus Scheduler · SVM Optimizer
# ─────────────────────────────────────────────────────────────────────────────

# ── MFE — Metric Feedback Engine ─────────────────────────────────────────────

def mfe_create() -> int:
    """Create an MFE handle.

    Returns an integer handle ID (≥ 1) that must be passed to all subsequent
    mfe_* calls.  Returns 0 on failure.

    The Metric Feedback Engine maintains an EMA (exponential moving average)
    feature buffer; typical use is to feed GPU perf-counter readings each
    forward-pass and read back mean/variance/std as an online quality signal.
    """
    try:
        from . import _C
        return int(_C.mfe_create())
    except (AttributeError, ImportError):
        return 0


def mfe_destroy(hid: int) -> None:
    """Destroy an MFE handle and free its internal buffer."""
    try:
        from . import _C
        _C.mfe_destroy(int(hid))
    except (AttributeError, ImportError):
        pass


def mfe_step(hid: int, features) -> bool:
    """Feed one feature vector into the EMA tracker.

    Args:
        hid:      Handle ID returned by mfe_create().
        features: Sequence of float values
                  (e.g. [gpu_util%, bandwidth_gbps, latency_us, ...]).
    Returns:
        True on success.
    """
    try:
        from . import _C
        return bool(_C.mfe_step(int(hid), [float(x) for x in features]))
    except (AttributeError, ImportError):
        return False


def mfe_set_decay(hid: int, decay: float) -> bool:
    """Set the EMA decay factor.

    Args:
        hid:   Handle ID.
        decay: Value in (0, 1).  Higher = smoother / slower adaptation.
               Default inside the engine: 0.99.
    """
    try:
        from . import _C
        return bool(_C.mfe_set_decay(int(hid), float(decay)))
    except (AttributeError, ImportError):
        return False


def mfe_read_metrics(hid: int, n: int = 8) -> list:
    """Read computed metrics from an MFE handle.

    Returns a list of float values:
      [mean, variance, std_dev, decay_factor, ...]  (up to n entries).
    """
    try:
        from . import _C
        return list(_C.mfe_read_metrics(int(hid), int(n)))
    except (AttributeError, ImportError):
        return [0.0] * n


def mfe_run_experiment(hid: int, exp_id: int = 0) -> bool:
    """Trigger a named experiment inside the handle.

    exp_id 0 = flush / reset the feature buffer.
    """
    try:
        from . import _C
        return bool(_C.mfe_run_experiment(int(hid), int(exp_id)))
    except (AttributeError, ImportError):
        return False


# ── Bus Scheduler ─────────────────────────────────────────────────────────────

def bus_init() -> bool:
    """Initialise the PCIe / NVMe bus enumerator.

    Enumerates all NVMe controllers and caches hardware config.
    Call once before any other bus_* function.
    """
    try:
        from . import _C
        return bool(_C.bus_init())
    except (AttributeError, ImportError):
        return False


def bus_cleanup() -> None:
    """Release bus scheduler resources."""
    try:
        from . import _C
        _C.bus_cleanup()
    except (AttributeError, ImportError):
        pass


def bus_get_optimal_config() -> dict:
    """Return the auto-selected best NVMe controller config as a dict.

    Fields: controller_id, device_name, model_name, vendor_id, device_id,
    configured_lanes, max_lanes, pcie_generation,
    theoretical_bw_gbps, actual_bw_gbps, peak_measured_bw_gbps,
    queue_depth, power_limit_active, thermal_throttling,
    motherboard_limitation, aspm_enabled, limitation_reason,
    avg_latency_us, utilization_pct.
    """
    import json
    try:
        from . import _C
        raw = _C.bus_get_optimal_config()
        return json.loads(raw)
    except (AttributeError, ImportError):
        return {"error": "bus_scheduler not available"}
    except Exception as e:
        return {"error": str(e)}


def bus_set_performance_mode(ctrl_id: int = 0, high_perf: bool = True) -> bool:
    """Switch a controller between high-performance and power-saving mode.

    Warning: high-performance mode increases power draw and temperature.
    """
    try:
        from . import _C
        return bool(_C.bus_set_performance_mode(int(ctrl_id), bool(high_perf)))
    except (AttributeError, ImportError):
        return False


def bus_get_optimization_suggestions(ctrl_id: int = 0) -> dict:
    """Return PCIe optimisation suggestions and BIOS recommendations as a dict.

    Useful for surfacing hardware-specific tuning advice to the user
    (e.g. "enable PCIe Gen5 in BIOS", "disable ASPM for lowest latency").
    """
    import json
    try:
        from . import _C
        raw = _C.bus_get_optimization_suggestions(int(ctrl_id))
        return json.loads(raw)
    except (AttributeError, ImportError):
        return {"error": "bus_scheduler not available"}
    except Exception as e:
        return {"error": str(e)}


def bus_benchmark_bandwidth(ctrl_id: int = 0, size_mb: int = 64) -> float:
    """Run a synchronous PCIe bandwidth micro-benchmark.

    Returns measured bandwidth in GB/s, or -1.0 on error.
    Typical RX 5700 XT + PCIe 4.0 x16: ~14–15 GB/s.
    """
    try:
        from . import _C
        return float(_C.bus_benchmark_bandwidth(int(ctrl_id), int(size_mb)))
    except (AttributeError, ImportError):
        return -1.0


def bus_monitor_status(ctrl_id: int = 0) -> dict:
    """Return a live status snapshot of a controller as a dict.

    Includes thermal, utilisation, and error statistics.
    """
    import json
    try:
        from . import _C
        raw = _C.bus_monitor_status(int(ctrl_id))
        return json.loads(raw)
    except (AttributeError, ImportError):
        return {"error": "bus_scheduler not available"}
    except Exception as e:
        return {"error": str(e)}


# ── SVM Optimizer ─────────────────────────────────────────────────────────────

def svm_suggest_optimization() -> dict:
    """Query NUMA-aware memory placement advice from the SVM topology engine.

    Builds a temporary SvmContext, queries placement hints, then tears it
    down.  Returns a dict parsed from the JSON advice string.

    Typical use: call before large batch inference to check if tensor
    memory is on the most efficient NUMA node for the current GPU.
    """
    import json
    try:
        from . import _C
        raw = _C.svm_suggest_optimization()
        try:
            return json.loads(raw)
        except Exception:
            return {"raw": raw}
    except (AttributeError, ImportError):
        return {"error": "svm_suggest_optimization not available"}


def svm_optimize_placement() -> bool:
    """Migrate pages to the optimal NUMA node in-place.

    Zero-argument call: the SVM engine internally reads the current
    allocation topology and migrates cold pages to match access patterns.
    Returns True on success.
    """
    try:
        from . import _C
        return bool(_C.svm_optimize_placement())
    except (AttributeError, ImportError):
        return False


def memory_summary(device=None) -> str:
    """印出 VRAM 統計 (類似 torch.cuda.memory_summary())。"""
    try:
        _C.vma_memory_summary()
        return ""
    except AttributeError:
        b = get_budget()
        lines = [
            "=== RetryIX VRAM Stats (no VMA) ===",
            f"  Total VRAM     : {b.get('total_vram',0) // 1024 // 1024} MB",
            f"  Used (driver)  : {b.get('used_vram', 0) // 1024 // 1024} MB",
            f"  Available      : {b.get('available_vram',0) // 1024 // 1024} MB",
        ]
        return "\n".join(lines)

def get_budget() -> dict:
    """回傳 VRAM budget dict: total/used/available/allocated_vma/block_bytes。"""
    try:
        return _C.vma_get_budget()
    except AttributeError:
        return {"total_vram": 0, "used_vram": 0, "available_vram": 0,
                "allocated_vma": 0, "block_bytes": 0}

def defragment_vram() -> bool:
    """VRAM 碎片整理 — OpenCL 完全沒有此功能，Vulkan+VMA 獨有。"""
    try:
        return _C.vma_defragment()
    except AttributeError:
        return False

def empty_cache():
    """釋放 VMA 未使用的 blocks (類似 torch.cuda.empty_cache())。
    目前等同呼叫 defragment + 觸發 Vulkan garbage collect。"""
    defragment_vram()

# 選擇性把這些函式注入到 torch.retryix 命名空間
def _inject_memory_api_to_torch():
    """將 memory_* 函式注入 torch.retryix，使 torch.retryix.memory_allocated() 可用。"""
    try:
        import torch
        _mod = getattr(torch, 'retryix', None)
        if _mod is not None:
            import pytorch_retryix_backend as _rx
            for _fn_name in ('memory_allocated', 'memory_reserved', 'memory_summary',
                             'get_budget', 'defragment_vram', 'empty_cache', 'vma_init'):
                if not hasattr(_mod, _fn_name):
                    setattr(_mod, _fn_name, getattr(_rx, _fn_name))
    except Exception:
        pass

# ── 動態後端選擇 API（直接從 _C 匯出，無需呼叫 init()） ─────────────────────
def get_backend() -> str:
    """回傳目前使用中的 RetryIX 後端名稱（'vulkan'、'opencl' 或 'cpu'）。"""
    try:
        from . import _C
        return _C.get_backend()
    except Exception:
        return 'unknown'

def set_backend(backend: str) -> None:
    """設定 RetryIX 後端。可選值：'vulkan'、'opencl'、'cpu'、'auto'。"""
    try:
        from . import _C
        _C.set_backend(backend)
    except Exception as e:
        raise RuntimeError(f"set_backend('{backend}') failed: {e}") from e


def set_cpu_fallback_prohibited(flag: bool) -> None:
    """啟用或禁用 CPU fallback 保護。

    在執行持久核心矩陣時呼叫此函數可確保
    後端不會退回 CPU；任何嘗試退回將拋出例外。

    範例：
        import pytorch_retryix_backend as prb
        prb.set_cpu_fallback_prohibited(True)
    """
    try:
        from . import _C
        _C.retryix_set_cpu_fallback_prohibited(bool(flag))
    except Exception as e:
        raise RuntimeError(f"set_cpu_fallback_prohibited failed: {e}") from e
