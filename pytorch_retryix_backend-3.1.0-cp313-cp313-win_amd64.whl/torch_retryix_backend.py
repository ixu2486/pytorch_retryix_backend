"""Compatibility shim — maps the common alias ``torch_retryix_backend``
to the actual package name ``pytorch_retryix_backend``.

Usage::

    import torch_retryix_backend as rxb   # works the same as:
    import pytorch_retryix_backend as rxb

Both names are equivalent.  The actual package lives in
``pytorch_retryix_backend``; this module simply re-exports everything from it.
"""
from pytorch_retryix_backend import *          # noqa: F401, F403
from pytorch_retryix_backend import __version__  # noqa: F401
import pytorch_retryix_backend as _real

# Make ``import torch_retryix_backend as rxb; rxb.init()`` etc. work by
# delegating attribute lookup to the real package at runtime.
import sys as _sys
_sys.modules[__name__] = _real
