# namespace package for shader assets
# left empty intentionally; files are included via package_data
